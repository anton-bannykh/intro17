public class CreateArrayException extends RuntimeException {
  public CreateArrayException(String message, Throwable cause) {
    super(message, cause);
  }
}
